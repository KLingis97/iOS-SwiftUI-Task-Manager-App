//
//  Views.swift
//  Task
//
//  Created by Kyriakos Lingis on 14/11/2023.
//

import Foundation

enum Views {
    case login, main, edit
}
