//
//  TextFieldStyle.swift
//  Task
//
//  Created by Kyriakos Lingis on 14/11/2023.
//

import Foundation

enum TextFieldStyle {
    
    case bordered, borderedSecure, underline, undelineSecure
}
